import torch.nn as nn
from torch.autograd import Variable
import torch
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence

class RecurrentNet(nn.Module):
    def __init__(self, rnn_type, n_users, input_size, embed_size, hidden_size, output_size, batch_size, \
                 n_layers=1, batch_first=False, nonlinearity = 'relu', dropout=0.5):
        super(RecurrentNet, self).__init__()

        self.embed_size = embed_size
        self.hidden_size = hidden_size
        self.batch_size = batch_size
        self.type = rnn_type

        self.user_embed = nn.Embedding(n_users, embed_size)
        self.poi_embed  = nn.Embedding(input_size, embed_size)

        if self.type =='LSTM':
            self.rnn = nn.LSTM(embed_size, hidden_size, n_layers, dropout=dropout)
        elif self.type == 'GRU':
            self.rnn = nn.GRU(embed_size, hidden_size, n_layers, nonlinearity=nonlinearity, dropout=dropout)
        elif self.type == 'RNN':
            self.rnn = nn.RNN(embed_size, hidden_size, n_layers, nonlinearity=nonlinearity, dropout=dropout)
        
        self.linear = nn.Linear(embed_size, output_size)
        # self.linear2 = nn.Linear(output_size*2, output_size)
        self.decoder = nn.Linear(hidden_size, output_size)
        self.softmax = nn.LogSoftmax(dim=1)


    def forward(self, user_tensor, poi_tensor, sorted_length):
        """user_tensor: seq_len(max_len) * batch_size (the element indicate the idx)
           embed_user:  seq_len(max_len) * batch_size * embed_size
           the seq_len of all kinds of tensors should be the same: longest length of all sequences

           refer to https://pytorch.org/docs/master/nn.html#torch.nn.utils.rnn.pack_padded_sequence
           the input of pack_padded_sequence: seq_len * batch_size * embed_size if batch_first is false
        """ 

        embed_user = self.user_embed(user_tensor) 
        embed_poi  = self.poi_embed(poi_tensor)

        packed_poi  = pack_padded_sequence(embed_poi, sorted_length.tolist())

        print("max len:", max(sorted_length.tolist()))
        print("packed_poi:", embed_poi.size()) # max_len_of_all x bz x   
        if torch.cuda.is_available():
            packed_poi = packed_poi.cuda()

        out, hidden = self.rnn(packed_poi)  # hidden: n_layers*n_directions x batch_size x hidden_size
        # print("size of hidden:", hidden.size())
        out, _ = pad_packed_sequence(out) # seq_len * batch_size * output_size
        # print("size of out:", out.size())

        out = self.decoder(out[-1, :, :]) # only take the output of last step
        user_pref = self.linear(embed_user)
        # pref = torch.cat((out, user_pref[0, :, :]), dim=1)
        pref = out + user_pref[0, :, :]
        # print("out:", out)
        # print("user_pref:", user_pref[0, :, :])
        # pref = self.linear2(pref)
        out = self.softmax(pref)
        return out

    def init_hidden(self):
        if self.type == "LSTM":
            return (Variable(torch.zeros((self.n_layers, self.batch_size, self.hidden_size))),
                             Variable(torch.zeros((self.n_layers, self.batch_size, self.hidden_size))))
        elif self.type in ('GRU', 'RNN'):
            return Variable(torch.zeros((self.n_layers, self.batch_size, self.hidden_size)))
