import os
data = 'fs'
city = 'tk'
wz = 12

predict = True

poi_cut = 0
protocol = 3

model_file = 'train_' + city + '.pt'
recommendation_file = 'recommendations' + city + '.csv'
if data == 'fs':
    PICKLE_FILE = '../datasets/foursquare_' + city + '/features_' + str(wz) + '_' + str(poi_cut) + '_p' + str(protocol) + '.pkl'
elif data == 'gw':
    PICKLE_FILE = '../datasets/gowalla_' + city + '/features_' + str(wz) + '_' + str(poi_cut) + '_p' + str(protocol) + '.pkl'


result_file = '../result.txt'

embed_size = 160
rnn_type = 'LSTM'
hidden_size = 64
batch_size = 64
learning_rate = 0.01
n_layers = 2
n_epochs = 30
# nonlinearity = 'tanh'
nonlinearity = 'relu'
dropout = 0.0
batch_first = False
update = 'SGD'
criterion = 'cross'
# criterion = 'nll' 

print("n_epoch:", embed_size, n_epochs)

