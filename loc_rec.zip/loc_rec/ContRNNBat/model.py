import torch.nn as nn
from torch.autograd import Variable
import torch
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence

class RecurrentNet(nn.Module):
    def __init__(self, rnn_type, n_users, n_hours, n_cates, input_size, embed_size, hidden_size, output_size, batch_size, \
                 n_layers=1, batch_first=False, nonlinearity = 'relu', dropout=0.5):
        super(RecurrentNet, self).__init__()

        self.embed_size = embed_size
        self.hidden_size = hidden_size
        self.batch_size = batch_size
        self.type = rnn_type

        self.user_embed = nn.Embedding(n_users, self.embed_size)
        self.hour_embed = nn.Embedding(n_hours, self.embed_size)
        self.poi_embed  = nn.Embedding(input_size, self.embed_size)
        self.cate_embed = nn.Embedding(n_cates, self.embed_size)

        if self.type =='LSTM':
            self.rnn = nn.LSTM(self.embed_size, hidden_size, n_layers, dropout = dropout)
        elif self.type == 'GRU':
            self.rnn = nn.GRU(self.embed_size, hidden_size, n_layers, dropout = dropout)
        elif self.type == 'RNN':
            self.rnn = nn.RNN(self.embed_size, hidden_size, n_layers, nonlinearity=nonlinearity, dropout=dropout)
        
        self.linear1 = nn.Linear(self.embed_size*3, self.embed_size)
        self.linear2 = nn.Linear(self.embed_size, output_size)
        self.decoder = nn.Linear(hidden_size, output_size)
        self.softmax = nn.LogSoftmax(dim=1)

        # self.dropout = nn.Dropout(dropout)

    def forward(self, user_tensor, hour_tensor, poi_tensor, cate_tensor, sorted_length):
        """user_tensor: seq_len(max_len) * batch_size (the element indicate the idx)
           embed_user:  seq_len(max_len) * batch_size * embed_size
           the seq_len of all kinds of tensors should be the same: longest length of all sequences

           refer to https://pytorch.org/docs/master/nn.html#torch.nn.utils.rnn.pack_padded_sequence
           the input of pack_padded_sequence: seq_len * batch_size * embed_size if batch_first is false
        """ 
        embed_user = self.user_embed(user_tensor) 
        embed_poi  = self.poi_embed(poi_tensor)
        embed_cate = self.cate_embed(cate_tensor)
        embed_hour = self.hour_embed(hour_tensor)

        # print("user poi cate hour sizes:", embed_user.size(), embed_poi.size(), embed_cate.size(), embed_hour.size())

        embed_cont = torch.cat((embed_poi, embed_cate, embed_hour), dim=2)
        # print("\nembed_cont size:", embed_cont.size())
        embed_cont = self.linear1(embed_cont)

        packed_cont = pack_padded_sequence(embed_cont, sorted_length.tolist())
        if torch.cuda.is_available():
            packed_cont = packed_cont.cuda()

        # out, hidden = self.rnn(packed_poi)
        out, hidden = self.rnn(packed_cont)
        out, _ = pad_packed_sequence(out) # seq_len * batch_size * output_size
        out = self.decoder(out[-1, :, :]) # only take the output of last step

        user_pref = self.linear2(embed_user)
        # print("out size:", out.size(), user_pref[0,:,:].size(), embed_user.size())
        user_pref = user_pref[0, :, :]
        pref = out + user_pref
        # pref = out
        out = self.softmax(pref)
        return out

    def init_hidden(self):
        if self.type == "LSTM":
            return (Variable(torch.zeros((self.n_layers, self.batch_size, self.hidden_size))),
                             Variable(torch.zeros((self.n_layers, self.batch_size, self.hidden_size))))
        elif self.type in ('GRU', 'RNN'):
            return Variable(torch.zeros((self.n_layers, self.batch_size, self.hidden_size)))
