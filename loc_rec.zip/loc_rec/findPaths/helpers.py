from math import asin, sqrt, cos, sin, exp, pi
import networkx as nx
from time import strptime


def compute_geodist(lat1, lon1, lat2, lon2):
    rad_lat1 = lat1*pi/180.0
    rad_lat2 = lat2*pi/180.0
    phi = rad_lat1 - rad_lat2
    lambdaa = lon1*pi/180.0 - lon2*pi/180.0
    u = sin(phi/2.0)
    v = sin(lambdaa/2.0)
    s = 2*asin(sqrt(u * u + cos(rad_lat1) * cos(rad_lat2) * v * v))
    return s * 6378.137

# match meta paths
# meta_path_list = ['uup', 'upp', 'upcp', 'up', 'upup']
def pathByMetaPaths(network, meta_path_list, path):
    '''
    :param network: graph
    :param meta_path_list: meta paths
    :param path: path
    :return: true or false
    '''
    path_type = ''.join([node[0] for node in path])
    if path_type not in meta_path_list:
        return False
    return True

# filter paths by time
def pathByTime(network, tm, path):
    '''
    :param path: a path represented by a list
    :return: a path
    '''
    for i in range(len(path) -1):
        source, target = path[i], path[i+1]
        if network[source][target]['type'] == 'up':
            checkin_time = network[source][target]['time']
            min_checkin_time = min(checkin_time)
            min_checkin_time = strptime(min_checkin_time, "%Y-%m-%dT%H:%M:%SZ")
            if min_checkin_time > tm:
                return False
    return True


def findPaths(network, meta_path_list, user, poi, tm, cutoff):
    all_paths = nx.all_simple_paths(network, user, poi, cutoff)
    all_paths = list(all_paths)
    # filter paths by time
    paths_filter = [path for path in all_paths if (pathByMetaPaths(network, meta_path_list, path) \
                                                   and pathByTime(network, tm, path))]
    return paths_filter


