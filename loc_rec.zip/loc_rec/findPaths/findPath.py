#build graph,

import os
import networkx as nx

from helpers import compute_geodist, findPaths
from para_config import *
import para_config

dataset = para_config.dataset

checkin_file = para_config.checkin_file
checkin_file = os.path.join('../datasets', dataset, checkin_file)

socialgraph_file = para_config.socialgraph_file
socialgraph_file = os.path.join('../datasets', dataset, socialgraph_file)

poi_info_file = para_config.poi_info_file
poi_info_file = os.path.join('../datasets', dataset, poi_info_file)


G = nx.Graph()

latlon_category_dict = {}
with open(poi_info_file, 'r') as rf:
    lines = rf.readlines()

# poi|latitude,longitude|city|categories|tags
for line in lines[1:]:
    line_list = line.strip().split('|')
    latlon = line_list[1]
    category = line_list[3].split(',')[0]
    latlon_category_dict[latlon] = category

# add user-poi, poi-category
with open(checkin_file, 'r') as rf:
    lines = rf.readlines()

poi_latlon_dict = {}
for line in lines[1:]:
    # user|poi|latitude|longitude|time
    line_list = line.strip().split('|')
    user, poi = line_list[0], line_list[1]
    lat, lon = line_list[2], line_list[3]
    latlon = lat + ',' + lon
    time = line_list[4]
    category = latlon_category_dict[latlon]
    if poi not in poi_latlon_dict:
        poi_latlon_dict[poi] = (lat, lon)
    user ='u_' + user
    poi = 'p_' + poi
    category = 'c_' + category
    if not G.has_edge(user, poi):
        G.add_edge(user, poi, type='up',time=[time])
    else:
        G[user][poi]['time'].append(time)
    if not G.has_edge(poi, category):
        G.add_edge(poi, category, type='pc', time='permanent')

# add user-user
with open(socialgraph_file, 'r') as rf:
    lines = rf.readlines()

for line in lines[1:]:
    # user1|user2
    line_list = line.strip().split('|')
    user1  = 'u_' + line_list[0]
    user2 = 'u_' + line_list[1]
    if not G.has_edge(user1, user2):
        G.add_edge(user1, user2, type='uu', time='permanent')

# add poi-poi
dist_cutoff = para_config.dist_cutoff
for poi1 in poi_latlon_dict:
    lat1, lon1 = poi_latlon_dict[poi1]
    for poi2 in poi_latlon_dict:
        if poi1 == poi2:
            continue
        if G.has_edge(poi1, poi2):
            continue
        lat2, lon2 = poi_latlon_dict[poi2]
        geo_dist = compute_geodist(float(lat1), float(lon1), float(lat2), float(lon2))
        if geo_dist < dist_cutoff:
            G.add_edge(poi1, poi2, type = 'pp', time='permanent')

print("the total number of nodes:", len(G.nodes()))
print("the number of users:", len([n for n in G.nodes() if n.startswith('u_')]))
print("the number of pois:", len([n for n in G.nodes() if n.startswith('p_')]))
print("the number of categories", len([n for n in G.nodes() if n.startswith('c_')]))
# print("finish")


#====================================
import os
from time import strptime
from time import strftime
import time

checkin_delimiter = '|'

def getKey(a):
    return a[2]

with open(checkin_file, 'r') as rf:
    lines = rf.readlines()

user_checkins_dict = {} #{user:[(poi1, time1), ()...]}
for line in lines[1:]: # user|poi|latitude|longitude|time
    if line == '':
        break
    line_list = line.strip().split(checkin_delimiter)
    user = line_list[0]
    poi = line_list[1]
    lat_lon = line_list[2] + ',' + line_list[3]
    tm = line_list[4]
    tm = strptime(tm, "%Y-%m-%dT%H:%M:%SZ")
    if user not in user_checkins_dict:
        user_checkins_dict[user] = [(poi, lat_lon, tm)]
    else:
        user_checkins_dict[user].append((poi, lat_lon, tm))

for user in user_checkins_dict:
    sorted_checkins = sorted(user_checkins_dict[user], key=getKey)
    user_checkins_dict[user] = sorted_checkins

# extract paths
# define meta paths.
# meta_path_list = ['uup', 'upp', 'upcp', 'up', 'upup']
all_meta_path_list = ['uup', 'upp', 'upcp']
social_meta_path_list = ['uup']
geo_meta_path_list = ['upp']
content_meta_path_list = ['upcp']
meta_path_type = para_config.meta_path_type
if meta_path_type == 'social':
    meta_path_list = social_meta_path_list
if meta_path_type == 'geo':
    meta_path_list = geo_meta_path_list
if meta_path_type == 'content':
    meta_path_list = content_meta_path_list
if meta_path_type == 'all':
    meta_path_list = all_meta_path_list


save_path_file = para_config.save_path_file
save_path_file = os.path.join('../datasets', dataset, save_path_file)
wf = open(save_path_file, 'w')
path_cutoff = para_config.path_cutoff
i = 0
for user in user_checkins_dict:
    print(i)
    i+=1
    checkins = user_checkins_dict[user]
    user = 'u_' + user
    for checkin in checkins:
        line_list = [user]
        poi= 'p_' + checkin[0]
        tm = checkin[2]
        paths = findPaths(G, meta_path_list, user, poi, tm, path_cutoff)
        tm = strftime("%Y-%m-%d %H:%M:%S", tm)
        line_list.append(poi)
        line_list.append(tm)
        for path in paths:
            path_str = ','.join(path)
            line_list.append(path_str)
        line = '\t'.join(line_list) + '\n'
        wf.write(line)
wf.close()





