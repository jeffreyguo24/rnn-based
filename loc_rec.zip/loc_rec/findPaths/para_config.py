city = '_ny'
dataset = 'foursquare' + city
checkin_file = 'qualified_checkin' + city + '.csv'
socialgraph_file = 'qualified_socialgraph' + city + '.csv'
meta_path_type = 'all'

# train_file = 'train_set_filter.csv'

poi_info_file = 'poi' + city + '.txt'
save_path_file = meta_path_type + '_paths.csv'

dist_cutoff = 3
path_cutoff = 4