import torch.nn as nn
from torch.autograd import Variable
import torch
import torch.nn.functional as F
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence


class Attn(nn.Module):
    def __init__(self, method, hidden_size):
        super(Attn, self).__init__()

        self.method = method
        self.hidden_size = hidden_size

        if self.method == 'general':
            self.linear = nn.Linear(self.hidden_size, hidden_size)

        elif self.method == 'concat':
            self.linear = nn.Linear(self.hidden_size * 2, hidden_size)
            self.v = nn.Parameter(torch.FloatTensor(hidden_size))

    def forward(self, hidden, encoder_outputs):
        n_nbrs = encoder_outputs.size(0) # encoder_outputs: n_nbrs x embed_size

        # print("n_nbrs", n_nbrs)
        # Create variable to store attention energies
        attn_energies = Variable(torch.zeros(n_nbrs)) # n_nbrs
        if torch.cuda.is_available():
            attn_energies = attn_energies.cuda()

        # For each batch of encoder outputs
        for n in range(n_nbrs):
            score = self.score(hidden, encoder_outputs[n])
            # print("score\n\n", score)
            attn_energies[n] = score

        attn_energies = F.softmax(attn_energies, dim=0)
        # print("attn_energies:", attn_energies.cpu())
        return attn_energies

    def score(self, hidden, encoder_output):

        if self.method == 'dot':
            energy = hidden.dot(encoder_output)
            return energy

        elif self.method == 'general':
            energy = self.linear(encoder_output)
            energy = hidden.dot(energy)
            return energy

        elif self.method == 'concat':
            # print("hidden type", hidden.type(), encoder_output.type())
            energy = self.linear(torch.cat((hidden, encoder_output), 0))
            # print("energy size, v size:", energy.size(), self.v.size())
            energy = self.v.dot(energy) # score(hidden, encoder_output) = w_a[hidden:encoder_output]
            return energy


class RecurrentNet(nn.Module):
    def __init__(self, rnn_type, n_users, n_hours, n_cates, input_size, embed_size, hidden_size, output_size, batch_size, \
                 n_layers=1, batch_first=False, nonlinearity = 'relu', dropout=0.5):
        super(RecurrentNet, self).__init__()

        self.embed_size = embed_size
        self.hidden_size = hidden_size
        self.batch_size = batch_size
        self.type = rnn_type

        self.user_embed = nn.Embedding(n_users, embed_size)
        self.hour_embed = nn.Embedding(n_hours, embed_size)
        self.poi_embed  = nn.Embedding(input_size, embed_size)
        self.cate_embed = nn.Embedding(n_cates, embed_size)

        self.attn = Attn("dot", self.embed_size)

        if self.type =='LSTM':
            self.rnn = nn.LSTM(embed_size, hidden_size, n_layers, dropout=dropout)
        elif self.type == 'GRU':
            self.rnn = nn.GRU(embed_size, hidden_size, n_layers, dropout=dropout)
        elif self.type == 'RNN':
            self.rnn = nn.RNN(embed_size, hidden_size, n_layers, nonlinearity=nonlinearity, dropout=dropout)
        
        self.linear1 = nn.Linear(embed_size*3, embed_size)
        self.linear2 = nn.Linear(embed_size, output_size)
        self.linear3 = nn.Linear(embed_size*2, embed_size)
        self.decoder = nn.Linear(hidden_size, output_size)
        self.softmax = nn.LogSoftmax(dim=1)

    def forward(self, user_tensor, hour_tensor, poi_tensor, cate_tensor, nbr_tensor, sorted_length):
        """user_tensor: seq_len(max_len) * batch_size (the element indicate the idx)
           embed_user:  seq_len(max_len) * batch_size * embed_size
           the seq_len of all kinds of tensors should be the same: longest length of all sequences

           refer to https://pytorch.org/docs/master/nn.html#torch.nn.utils.rnn.pack_padded_sequence
           the input of pack_padded_sequence: seq_len * batch_size * embed_size if batch_first is false
        """ 
        embed_user = self.user_embed(user_tensor) # seq_len * batch_size * embed_size 
        embed_poi  = self.poi_embed(poi_tensor)
        embed_cate = self.cate_embed(cate_tensor)
        embed_hour = self.hour_embed(hour_tensor)

        """
        find neighbors 
        poi_tensor: max_len x batch_size x embed_size
        the length is already sorted, so the first seq of poi_tensor[:, 0, :] is max_len

        
        t_embed_list = max_len x batch_size x embed_size
        max_len  = poi_tensor.size()[0]
        for t in range(max_len):
            attn_weights = self.attn(t_embed, alistofembeddings)
            context = attn_weights.bmm(alistofembeddings)
            t_embed = F.tanh(self.linear3(torch.cat(t_embed, context)))
            put t_embed into t_embed_list
        """

        max_len, batch_size, n_nbrs = nbr_tensor.size() # max_len x batch_size x n_nbrs
        # embed_pois: store the embeddings of current poi and its neighbors
        embed_pois = Variable(torch.zeros(max_len, batch_size, self.embed_size))

        for b in range(batch_size):
            for t in range(sorted_length.cpu().numpy()[b]):
                bt_embed_poi = embed_poi[t, b] # embed_size
                bt_embed_nbrs = Variable(torch.zeros(n_nbrs, self.embed_size))
                if torch.cuda.is_available():
                    bt_embed_nbrs = bt_embed_nbrs.cuda()
                # now get the nbr_tensor
                for n in range(n_nbrs):
                    embed_nbr = self.poi_embed(nbr_tensor[t, b, n]) # size: embed_size
                    # if n == 1:
                    #     print("embed_nbr:", embed_nbr.size())
                    bt_embed_nbrs[n] = embed_nbr

                attn_weights = self.attn(bt_embed_poi, bt_embed_nbrs) # n_nbrs
                attn_weights = attn_weights.unsqueeze(0) # 1 x n_nbrs
                # print("\n b, t", b, t)
                # print("bt_embed_poi:", bt_embed_poi)
                # print("attn_weights:", attn_weights)
                # print("bt_embed_nbrs:", bt_embed_nbrs)
                context = torch.matmul(attn_weights, bt_embed_nbrs) # context: 1 x embed_size
                context = context.squeeze(0) # context: embed_size
                # print("context:", context)
                concat_embed = torch.cat((bt_embed_poi, context), 0)
                concat_embed = F.tanh(self.linear3(concat_embed)) # concat_embed: batch_size x embed_size
                # print("concat_embed size:", concat_embed.size())
                embed_pois[t, b, :] = concat_embed # embed_pois: max_len x batch_size x embed_size

        if torch.cuda.is_available():
            embed_pois = embed_pois.cuda()
        embed_cont = torch.cat((embed_pois, embed_cate, embed_hour), 2)
        embed_cont = self.linear1(embed_cont)
        packed_cont = pack_padded_sequence(embed_cont, sorted_length.tolist())
        if torch.cuda.is_available():
            packed_cont = packed_cont.cuda()

        out, hidden = self.rnn(packed_cont) # hidden: n_layers*n_directions x batch_size x hidden_size
        out, _ = pad_packed_sequence(out) # seq_len * batch_size * output_size
        out = self.decoder(out[-1, :, :]) # only take the output of last step

        user_pref = self.linear2(embed_user)
        pref = out + user_pref[0, :, :]
        out = self.softmax(pref)
        return out

    def init_hidden(self):
        if self.type == "LSTM":
            return (Variable(torch.zeros((self.n_layers, self.batch_size, self.hidden_size))),
                             Variable(torch.zeros((self.n_layers, self.batch_size, self.hidden_size))))
        elif self.type in ('GRU', 'RNN'):
            return Variable(torch.zeros((self.n_layers, self.batch_size, self.hidden_size)))
