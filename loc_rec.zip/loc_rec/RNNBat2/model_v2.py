import torch.nn as nn
from torch.autograd import Variable
import torch
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence
import torch.nn.functional as F

class RecurrentNet(nn.Module):

    def __init__(self, rnn_type, n_users, input_size, embed_size, hidden_size, output_size, batch_size, \
                 n_layers=1, batch_first=False, nonlinearity = 'relu', dropout=0.5):
        super(RecurrentNet, self).__init__()

        self.embed_size = embed_size
        self.hidden_size = hidden_size
        self.batch_size = batch_size
        self.type = rnn_type
        self.n_users = n_users
        self.output_size = output_size

        self.user_embed = nn.Embedding(n_users, embed_size)
        self.poi_embed  = nn.Embedding(input_size, embed_size)

        if self.type =='LSTM':
            self.rnn = nn.LSTM(2*embed_size, hidden_size, n_layers, nonlinearity=nonlinearity, dropout=dropout)
        elif self.type == 'GRU':
            self.rnn = nn.GRU(embed_size, hidden_size, n_layers, nonlinearity=nonlinearity, dropout=dropout)
        elif self.type == 'RNN':
            self.rnn = nn.RNN(embed_size, hidden_size, n_layers, nonlinearity=nonlinearity, dropout=dropout)
        
        self.linear = nn.Linear(embed_size, output_size)
        self.decoder = nn.Linear(hidden_size, output_size)
        self.softmax = nn.LogSoftmax(dim=1)

    def compute_sim(self, embed1, embeds):
        cos = nn.CosineSimilarity(dim=0, eps=1e-6)
        n = self.n_users
        sims = torch.zeros(n)
        for i in range(n):
            sims[i] = cos(embed1, embeds[i])
        sims = F.normalize(sims, dim=0)
        return sims

    def forward(self, all_users, all_pois, user_tensor, poi_tensor, sorted_length):
        """user_tensor: seq_len(max_len) * batch_size (the element indicate the idx)
           embed_user:  seq_len(max_len) * batch_size * embed_size
           the seq_len of all kinds of tensors should be the same: longest length of all sequences

           refer to https://pytorch.org/docs/master/nn.html#torch.nn.utils.rnn.pack_padded_sequence
           the input of pack_padded_sequence: seq_len * batch_size * embed_size if batch_first is false
        """ 

        batch_size = user_tensor.size()[1]
        seq_len = sorted_length.tolist()[0]

        embed_user = self.user_embed(user_tensor) 
        embed_poi  = self.poi_embed(poi_tensor)

        # embed_con  = self.linear2(torch.cat((embed_poi, embed_user), dim=2))

        packed_poi  = pack_padded_sequence(embed_poi, sorted_length.tolist())
        # packed_poi  = pack_padded_sequence(embed_con, sorted_length.tolist())

        # print("packed_poi:", embed_poi.size())
        if torch.cuda.is_available():
            packed_poi = packed_poi.cuda()

        out, hidden = self.rnn(packed_poi)  # hidden: n_layers*n_directions x batch_size x hidden_size
        # print("size of hidden:", hidden.size())
        out, _ = pad_packed_sequence(out) # seq_len * batch_size * hidden_size
        # print("out size:", out.size(), embed_user.size(), sorted_length.tolist())
        # out = out + self.linear4(embed_user)[:seq_len]
        # print("size of out:", out.size())
        out_last = out[-1, :, :]  # only take the output of last step
        out_last = self.decoder(out_last) # batch_size x embed_size

        embed_user = embed_user[0, :, :] # only need to get the first  
        user_pref = self.linear(embed_user)

        # poi_pref = Variable(torch.zeros((batch_size, self.output_size)))

        #poi_pref[b][o] = (out_last + user_pref) * poi_embed
        #batch_size x 
        # all_embeds = self.poi_embed(all_pois) # n_pois x embed_size
        # i = 0
        # for embed in all_embeds:
        #     # for b in range(batch_size):
        #     poi_pref[:,i] = torch.matmul((out_last + embed_user), embed)
        #     # print("poi_pref:", poi_pref[:,i])
        #     i+= 1
        # print("poi_pref size:", poi_pref.size())

        pref = out_last + user_pref
        
        # out size: batch_size x output_size
        out = self.softmax(pref)
        return out

    def init_hidden(self):
        if self.type == "LSTM":
            return (Variable(torch.zeros((self.n_layers, self.batch_size, self.hidden_size))),
                             Variable(torch.zeros((self.n_layers, self.batch_size, self.hidden_size))))
        elif self.type in ('GRU', 'RNN'):
            return Variable(torch.zeros((self.n_layers, self.batch_size, self.hidden_size)))
