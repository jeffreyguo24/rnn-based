import os
import pickle
from datetime import datetime

import math
from random import shuffle

from helpers import get_train_sample
from model_v3 import *
import para_config

import torch
from torch.autograd import Variable
import numpy as np
import torch.nn as nn
from torch.nn.utils import clip_grad_norm_ as clip_grad_norm
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence
from torch.optim.lr_scheduler import ReduceLROnPlateau
from torch.utils.data import DataLoader
from torch.utils import data

from sklearn.model_selection import StratifiedShuffleSplit
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score

import matplotlib as mpl
if os.environ.get('DISPLAY','') == '':
    print('no display found. Using non-interactive Agg backend')
    mpl.use('Agg')
import matplotlib.pyplot as plt

# read parameters
city          = para_config.city
predict       = para_config.predict

pickle_file   = para_config.PICKLE_FILE
model_file    = para_config.model_file

lr            = para_config.learning_rate
rnn_type      = para_config.rnn_type
n_epochs      = para_config.n_epochs
embed_size    = para_config.embed_size
hidden_size   = para_config.hidden_size
batch_size    = para_config.batch_size
n_layers      = para_config.n_layers
update        = para_config.update
dropout       = para_config.dropout
nonlinearity  = para_config.nonlinearity
batch_first   = para_config.batch_first
criterion     = para_config.criterion

result_file   = para_config.result_file

print("===================load train and test data====================\n")

with (open(pickle_file, "rb")) as fp:
    data_obj = pickle.load(fp)

user_all_trajs, user_train_trajs, user_test_trajs, poi_info, user_index, poi_index, cate_index = data_obj
n_users, n_pois  = len(user_index.keys()), len(set([idx for poi, idx in poi_index.items()]))
n_hours, n_cates = 48, len(cate_index.keys())
n_train_trajs = sum([len(user_train_trajs[u]) for u in user_train_trajs])
n_test_trajs  = sum([len(user_test_trajs[u]) for u in user_test_trajs])


def compute_geodist(lat1, lon1, lat2, lon2):
    lat1, lon1, lat2, lon2 = float(lat1), float(lon1), float(lat2), float(lon2)
    rad_lat1 = lat1*pi/180.0
    rad_lat2 = lat2*pi/180.0
    phi = rad_lat1 - rad_lat2
    lambdaa = lon1*pi/180.0 - lon2*pi/180.0
    u = sin(phi/2.0)
    v = sin(lambdaa/2.0)
    s = 2*asin(sqrt(u * u + cos(rad_lat1) * cos(rad_lat2) * v * v))
    return s * 6378.137

def get_poi_info(poi_info, poi_index):
    pois = {}
    for p, i in poi_index.items():
        pois[i] = poi_info[p]
    return pois

def load_trajs(user_trajs):
    """create features for trajectories
    """
    traj_feas = []
    for user, trajs in user_trajs.items():
        for traj in trajs: # trajs:[ [[ui, hour, poi, cate],[record2], ], traj2, ]
            tar = traj[-1]
            traj_feas += [(traj[:-1], tar)]
    return traj_feas

def sort_batch_data(data):
    # data: [[(name, target), len of name], ...]
    bat_users, bat_hours, bat_pois, bat_cates, bat_tars = data[0]
    bat_lens = data[1]
    sorted_lens, sorted_id = bat_lens.sort(dim=0, descending=True)
    sorted_users = bat_users[sorted_id]
    sorted_hours = bat_hours[sorted_id]
    sorted_pois  = bat_pois[sorted_id]
    sorted_cates = bat_cates[sorted_id]
    sorted_tars  = bat_tars[sorted_id]
    return Variable(torch.t(sorted_users)), Variable(torch.t(sorted_hours)), \
           Variable(torch.t(sorted_pois)) , Variable(torch.t(sorted_cates)),\
           Variable(sorted_tars).squeeze(), sorted_lens

class TrajDataset(data.Dataset):
    def __init__(self, data):
        super(TrajDataset, self).__init__()
        self.data = data 
        self.trajs = [x[0] for x in data]
        self.users = [[record[0] for record in traj] for traj in self.trajs]
        self.hours = [[record[1] for record in traj] for traj in self.trajs]
        self.pois  = [[record[2] for record in traj] for traj in self.trajs]
        self.cates = [[record[3] for record in traj] for traj in self.trajs]
        self.tars  = [x[1] for x in data]
        self.n_sample = len(self.data)
        self.lengths = [len(x[0]) for x in data] # list of lengh of trajs

        self.user_tensor = torch.zeros((self.n_sample, max(self.lengths))).long()
        self.hour_tensor = torch.zeros((self.n_sample, max(self.lengths))).long()
        self.poi_tensor  = torch.zeros((self.n_sample, max(self.lengths))).long()
        self.cate_tensor = torch.zeros((self.n_sample, max(self.lengths))).long()
        self.tar_tensor  = torch.zeros((self.n_sample, 1)).long()
        self.process_data()

    def process_data(self):
        for i in range(self.n_sample):
            traj, tar = self.data[i]
            tar_poi = tar[2]
            i_users, i_hours, i_pois, i_cates = self.users[i], self.hours[i], self.pois[i], self.cates[i]
            self.user_tensor[i, :self.lengths[i]] = self.convert_to_tensor(i_users)
            self.hour_tensor[i, :self.lengths[i]] = self.convert_to_tensor(i_hours)
            self.poi_tensor[i,  :self.lengths[i]] = self.convert_to_tensor(i_pois)
            self.cate_tensor[i, :self.lengths[i]] = self.convert_to_tensor(i_cates)
            self.tar_tensor[i,  :]                = self.convert_to_tensor([tar_poi])

    @staticmethod
    def convert_to_tensor(alist):
        return torch.LongTensor(alist)

    def __getitem__(self, idx):
        return [(self.user_tensor[idx], self.hour_tensor[idx], self.poi_tensor[idx], \
                 self.cate_tensor[idx], self.tar_tensor[idx]), self.lengths[idx]]

    def __len__(self):
        return len(self.data)

def save(model):
    torch.save(model, model_file)
    print('Saved as %s' % model_file)

def train(train_data, pois):
    # set start time
    start_time = datetime.now()
    print("start time:", start_time)

    model = RecurrentNet('RNN', n_users, n_pois, embed_size, hidden_size, n_pois, batch_size, \
                          n_layers, batch_first, nonlinearity, dropout)

    if torch.cuda.is_available():
        print("gpu is used!")
        model = model.cuda()

    if criterion == 'cross':
        loss_fn = nn.CrossEntropyLoss()
    elif criterion == 'nll':
        loss_fn = nn.NLLLoss()

    if update == "Adam":
        optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=0.0005)
    elif update == "SGD":
        optimizer = torch.optim.SGD(model.parameters(), lr=lr, momentum=0.9)
    optim_scheduler = ReduceLROnPlateau(optimizer, mode='min', factor=0.1, verbose=True, patience=1)
    all_users = Variable(torch.tensor([i for i in range(n_users)]))
    loss_cache = []
    for epoch in range(n_epochs):
        total_loss = []
        for batch_data in train_data:
            bat_users, bat_hours, bat_pois, bat_cates, bat_tars, bat_lens = sort_batch_data(batch_data)
            bat_size = len(bat_lens)
            # print("bat_users:", bat_users.size(), torch.max(bat_lens))
            # print("bat_tars:",  bat_tars)
            if torch.cuda.is_available():
                bat_users, bat_hours, bat_pois = bat_users.cuda(), bat_hours.cuda(), bat_pois.cuda()
                bat_cates, bat_lens  = bat_cates.cuda(), bat_lens.cuda()
                all_users = all_users.cuda()
            # print("bat_len size:", bat_lens)
            model.zero_grad()
            tar_score = model(pois, all_users, bat_users, bat_pois, bat_lens)
            # print("size:", tar_score.size(), bat_pois.size())
            loss = loss_fn(tar_score.cpu(), bat_tars)
            # print("loss", loss.size())
            loss.backward()
            clip_grad_norm(model.parameters(), max_norm=10)
            optimizer.step()
            total_loss.append(loss.data.item() * bat_size)
        loss_avg = sum(total_loss) / len(total_loss)
        optim_scheduler.step(loss_avg)
        # if epoch % 10 == 0:
        print("Epoch {} : {:.5f}".format(epoch+1, loss_avg))
        loss_cache.append(loss_avg)

    save(model)
    plt.plot(loss_cache)
    plt.savefig('./loss.png')
    print(datetime.now())
    print("training time is: ", datetime.now()-start_time)

    return model


def evaluation(tar_true, tar_pred_1, tar_pred_20):
    for i in range(len(tar_true)):
        if tar_pred_1[i] != tar_pred_20[i][0]:
            print("wrong!")

    acc_1, acc_5, acc_10, acc_20 = 0.0, 0.0, 0.0, 0.0
    for i in range(len(tar_true)):
        tar = tar_true[i]
        pred = tar_pred_20[i]
        if tar == pred[0]:
            acc_1 += 1
        if tar in pred[:5]:
            acc_5 += 1
        if tar in pred[:10]:
            acc_10 += 1
        if tar in pred[:20]:
            acc_20 += 1
    i += 1
    acc_1, acc_5, acc_10, acc_20 = acc_1/i, acc_5/i, acc_10/i, acc_20/i
    return acc_1, acc_5, acc_10, acc_20


def prediction(model, test_data, pois):
    tar_pred_1, tar_true = [], []
    tar_pred_20 = []
    all_users = Variable(torch.tensor([i for i in range(n_users)]))
    for batch_data in test_data:
        bat_users, bat_hours, bat_pois, bat_cates, bat_tars, bat_lens = sort_batch_data(batch_data)
        if bat_lens.size()[0] == 1:
            bat_tars = Variable(torch.Tensor([bat_tars.data.item()]))
        # print("bat_len:", bat_lens)
        if torch.cuda.is_available():
            bat_users, bat_hours, bat_pois = bat_users.cuda(), bat_hours.cuda(), bat_pois.cuda()
            bat_cates, bat_lens  = bat_cates.cuda(), bat_lens.cuda()
            all_users = all_users.cuda()
        tar_score = model(pois, all_users, bat_users, bat_pois, bat_lens)
        tar_score = tar_score.cpu()

        #####
        # batch_size = bat_pois.size()[1]
        # last_pois = [] # batch_size
        # for b in range(batch_size):
        #     poi = bat_pois.data[bat_lens.tolist()[b] - 1, b]
        #     last_pois.append(poi.item())
        # n_pois = len(pois)
        # for b in range(batch_size):
        #     last_poi = last_pois[b]
        #     lat1, lon1 = pois[last_poi][1], pois[last_poi][2]
        #     for p in range(n_pois):
        #         lat2, lon2 = pois[p][1], pois[p][2]
        #         # print("latlon", lat1, lon1, lat2, lon2)
        #         dist = compute_geodist(lat1, lon1, lat2, lon2)
        #         # print("dist:", dist)
        #         dist = exp(-0.5*dist)
        #         tar_score.data[b, p] = tar_score.data[b, p] * dist
        #####

        score, score_idx = torch.max(tar_score, dim=1)
        tar_pred_1 += score_idx.data.tolist()
        sort_score, indices = torch.sort(tar_score, dim=1, descending=True)
        # print("sorted indices:", sort_score.size())
        indices = [ind[:20] for ind in indices.data.tolist()]
        tar_pred_20 += indices
        tar_true += bat_tars.data.tolist()

    print("size:", len(tar_true), len(tar_pred_1), len(tar_pred_20))
    return tar_true, tar_pred_1, tar_pred_20


def main():

    print("=======================start training=========================\n")
    print("training file:", pickle_file)
    print("users, pois, cates, train_trajs, test_trajs")
    print(n_users, n_pois, n_cates, n_train_trajs, n_test_trajs)

    pois = get_poi_info(poi_info, poi_index)
    train_trajs = load_trajs(user_train_trajs)
    train_set   = TrajDataset(train_trajs)
    train_data  = DataLoader(train_set, batch_size, shuffle=True)
    model = train(train_data, pois)

    print("=======================start predicting=========================\n")
    model       = torch.load(model_file)
    test_trajs  = load_trajs(user_test_trajs)
    test_set    = TrajDataset(test_trajs)
    test_data   = DataLoader(test_set, batch_size, shuffle=False)
    if predict == True:
        tar_true, tar_pred_1, tar_pred_20 = prediction(model, test_data, pois)
        accuracy = accuracy_score(tar_true, tar_pred_1)
        print("Accuracy rate is {:.4f}".format(accuracy))
        results = evaluation(tar_true, tar_pred_1, tar_pred_20)
        acc_1, acc_5, acc_10, acc_20 = results
        print(acc_1, acc_5, acc_10, acc_20)

    parameters = [str(datetime.now()), 'RNNBat2', city, lr, rnn_type, n_epochs, embed_size, hidden_size, batch_size, n_layers, update,\
                    dropout, nonlinearity, batch_first, criterion]  
    parameters = [str(para) for para in parameters]

    with open(result_file, 'a') as fp:
        line = ','.join(parameters)
        fp.write(line + '\n')
        line = ','.join([str(acc) for acc in results])
        fp.write(line + '\n')

if __name__ == "__main__":
    main()