import torch.nn as nn
from torch.autograd import Variable
import torch
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence
import torch.nn.functional as F
from math import asin, sqrt, cos, sin, exp, pi


class PreTrain(nn.Module):
    pass

class RecurrentNet(nn.Module):

    def __init__(self, rnn_type, n_users, input_size, embed_size, hidden_size, output_size, batch_size, \
                 n_layers=1, batch_first=False, nonlinearity = 'relu', dropout=0.5):
        super(RecurrentNet, self).__init__()

        self.embed_size = embed_size
        self.hidden_size = hidden_size
        self.batch_size = batch_size
        self.type = rnn_type
        self.n_users = n_users

        self.user_embed = nn.Embedding(n_users, embed_size)
        self.poi_embed  = nn.Embedding(input_size, embed_size)

        if self.type =='LSTM':
            self.rnn = nn.LSTM(2*embed_size, hidden_size, n_layers, nonlinearity=nonlinearity, dropout=dropout)
        elif self.type == 'GRU':
            self.rnn = nn.GRU(embed_size, hidden_size, n_layers, nonlinearity=nonlinearity, dropout=dropout)
        elif self.type == 'RNN':
            self.rnn = nn.RNN(embed_size, hidden_size, n_layers, nonlinearity=nonlinearity, dropout=dropout)
        
        self.linear = nn.Linear(embed_size, output_size)
        self.decoder = nn.Linear(hidden_size, output_size)
        self.softmax = nn.LogSoftmax(dim=1)


    def compute_geodist(self, lat1, lon1, lat2, lon2):
        lat1, lon1, lat2, lon2 = float(lat1), float(lon1), float(lat2), float(lon2)
        rad_lat1 = lat1*pi/180.0
        rad_lat2 = lat2*pi/180.0
        phi = rad_lat1 - rad_lat2
        lambdaa = lon1*pi/180.0 - lon2*pi/180.0
        u = sin(phi/2.0)
        v = sin(lambdaa/2.0)
        s = 2*asin(sqrt(u * u + cos(rad_lat1) * cos(rad_lat2) * v * v))
        return s * 6378.137


    def forward(self, pois, all_users, user_tensor, poi_tensor, sorted_length):
        """user_tensor: seq_len(max_len) * batch_size (the element indicate the idx)
           embed_user:  seq_len(max_len) * batch_size * embed_size
           the seq_len of all kinds of tensors should be the same: longest length of all sequences

           refer to https://pytorch.org/docs/master/nn.html#torch.nn.utils.rnn.pack_padded_sequence
           the input of pack_padded_sequence: seq_len * batch_size * embed_size if batch_first is false
        """ 

        batch_size = user_tensor.size()[1]
        seq_len = sorted_length.tolist()[0]

        embed_user = self.user_embed(user_tensor) 
        embed_poi  = self.poi_embed(poi_tensor)
        packed_poi  = pack_padded_sequence(embed_poi, sorted_length.tolist())

        # last_pois = [] # batch_size
        # for b in range(batch_size):
        #     poi = poi_tensor.data[sorted_length.tolist()[b] - 1, b]
        #     last_pois.append(poi.item())
        # n_pois = len(pois)

        if torch.cuda.is_available():
            packed_poi = packed_poi.cuda()

        out, hidden = self.rnn(packed_poi)  # hidden: n_layers*n_directions x batch_size x hidden_size
        # print("size of hidden:", hidden.size())
        out, _ = pad_packed_sequence(out) # seq_len * batch_size * hidden_size
        # print("out size:", out.size(), embed_user.size(), sorted_length.tolist())
        # out = out + self.linear4(embed_user)[:seq_len]
        # print("size of out:", out.size())
        out_last = out[-1, :, :]  # only take the output of last step
        out_last = self.decoder(out_last) # batch_size x output_size

        embed_user = embed_user[0, :, :] # only need to get the first  
        
        user_pref = self.linear(embed_user)

        pref = out_last + user_pref  
        # pref = out_last      
        out = self.softmax(pref) # batch_size x output_size
        # out = self.softmax(out)

        # print("out", out)
        # add dsitance info
        #exp(-distance)
        # for b in range(batch_size):
        #     last_poi = last_pois[b]
        #     lat1, lon1 = pois[last_poi][1], pois[last_poi][2]
        #     for p in range(n_pois):
        #         lat2, lon2 = pois[p][1], pois[p][2]
        #         # print("latlon", lat1, lon1, lat2, lon2)
        #         dist = self.compute_geodist(lat1, lon1, lat2, lon2)
        #         # print("dist:", dist)
        #         dist = exp(-0.5*dist)
        #         out.data[b, p] = out.data[b, p] * dist
        return out

    def init_hidden(self):
        if self.type == "LSTM":
            return (Variable(torch.zeros((self.n_layers, self.batch_size, self.hidden_size))),
                             Variable(torch.zeros((self.n_layers, self.batch_size, self.hidden_size))))
        elif self.type in ('GRU', 'RNN'):
            return Variable(torch.zeros((self.n_layers, self.batch_size, self.hidden_size)))
