import torch.nn as nn
from torch.autograd import Variable
import torch

class RNN(nn.Module):
    def __init__(self, rnn_type, input_size, embedding_size, hidden_size, output_size, n_layers=1, batch_first=True, \
                 nonlinearity = 'relu', dropout = 0.5):

        super(RNN, self).__init__()

        # set embeddings
        self.encoder = nn.Embedding(input_size, embedding_size)
        self.rnn_type = rnn_type
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size
        self.n_layers = n_layers
        self.batch_first = batch_first
        self.dropout = nn.Dropout(dropout)

        if rnn_type == 'RNN':
            self.rnn = nn.RNN(embedding_size, hidden_size, n_layers,\
                        nonlinearity=nonlinearity, dropout=dropout)
        elif rnn_type == "GRU":
            self.rnn = nn.GRU(embedding_size, hidden_size, n_layers, \
                        nonlinearity=nonlinearity, dropout=dropout)
        elif rnn_type == "LSTM":
            self.rnn = nn.LSTM(embedding_size, hidden_size, n_layers, \
                        nonlinearity=nonlinearity, dropout=dropout)

        self.decoder = nn.Linear(hidden_size, output_size)
        # self.softmax = nn.LogSoftmax()
        self.softmax = nn.Softmax(dim=1)

    def forward(self, poi):
        # get poi embedding
        poi_embedding = self.encoder(poi.view(1, -1))
        if torch.cuda.is_available():
            poi_embedding = poi_embedding.cuda()
        out, hidden = self.rnn(poi_embedding.view(1, 1, -1))
        out = self.decoder(out.view(1, -1))
        # print("\nout in forwad:", out, out.size())
        out = self.softmax(out)
        # print("\nout in forwad:", out, out.size())
        return out

    def init_hidden(self):
        if self.rnn_type in ('RNN', 'GRU'):
            return Variable(torch.zeros(self.n_layers, 1, self.hidden_size))
        else:
            return (Variable(torch.zeros(self.n_layers, 1, self.hidden_size)),\
                Variable(torch.zeros(self.n_layers, 1, self.hidden_size)))
