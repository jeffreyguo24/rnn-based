# https://github.com/spro/practical-pytorch
import torch
from torch.autograd import Variable

# One-hot matrix of first to last letters for input
def inp_Tensor(seq, poi_index):
    tensor = torch.zeros(len(seq)).long()
    for i in range(len(seq)):
        # print("seq i:", seq[i])
        tensor[i] = poi_index[seq[i]]
    return Variable(tensor)

def tar_Tensor(tar, poi_index):
    tensor = torch.zeros(1).long()
    tensor[0] = poi_index[tar]
    return Variable(tensor)

def get_train_sample(seq, poi_index):
    # print("seq:", seq)
    inp = inp_Tensor(seq[:-1], poi_index) 
    tar = tar_Tensor(seq[-1], poi_index)
    return inp, tar

def time_since(since):
    s = time.time() - since
    m = math.floor(s / 60)
    s -= m * 60
    return '%dm %ds' % (m, s)