# https://github.com/spro/practical-pytorch

import os
import pickle

import torch
from torch.autograd import Variable
import numpy as np
import torch.nn as nn

from helpers import get_train_sample
from model import *
import para_config

from random import shuffle
import math

print('\n=================== start training =======================\n')
# read parameters
city = para_config.city
pickle_file = para_config.PICKLE_FILE
model_file = para_config.model_file

rnn_type = para_config.rnn_type
n_epochs = para_config.n_epochs
embedding_size = para_config.embedding_size
hidden_size = para_config.hidden_size
n_layers = para_config.n_layers
learning_rate = para_config.learning_rate
update = para_config.update
dropout = para_config.dropout
nonlinearity = para_config.nonlinearity
batch_first = para_config.batch_first


print("===================load train and test data====================\n")
with (open(pickle_file, "rb")) as fp:
    data_obj = pickle.load(fp)

user_all_trajs, user_train_trajs, user_test_trajs, pois, user_index, poi_index = data_obj
n_users, n_pois = len(user_train_trajs.keys()), len(pois.keys())

print("=======================start training=========================\n")
print("users and pois:", n_users, n_pois)
rnn_model = RNN(rnn_type, n_pois, embedding_size, hidden_size, n_pois, n_layers, \
                batch_first, nonlinearity, dropout)

if torch.cuda.is_available():
    rnn_model = rnn_model.cuda()

if update == 'Adam':
    rnn_model_optimizer = torch.optim.Adam(rnn_model.parameters())
else:
    rnn_model_optimizer = torch.optim.SGD(rnn_model.parameters(), lr=learning_rate)
criterion = nn.CrossEntropyLoss()
# criterion = nn.NLLLoss()

# set start time
from datetime import datetime
start_time = datetime.now()
print("start time:", start_time)

#*********************
# define train method
#*********************

def train(user, inp, tar):
    loss = 0
    rnn_model.zero_grad()
    for p in range(len(inp)):
        # print("inp[p]:", inp[p])
        out = rnn_model(inp[p])
    # print("output:", out, out.size())
    loss = criterion(out.cpu(), tar)
    # print("loss:", type(loss))
    loss.backward()

    # for p in rnn_model.parameters():
    #     p.data.add_(-learning_rate, p.grad.data)
    rnn_model_optimizer.step()
    # print("loss:", loss.data[0])
    return loss.item()

def save():
    torch.save(rnn_model, model_file)
    print('Saved as %s' % model_file)


try:
    print("Training for %d epochs..." % n_epochs)
    users = list(user_train_trajs.keys())
    for p in rnn_model.parameters():
        print(p.size())
    for name, param in rnn_model.named_parameters():
        print(name, param.size())
    # hidden = rnn_model.init_hidden()
    for epoch in range(n_epochs):
        print("=====epoch:", epoch, "=====")
        loss_avg = 0.0
        count_user, count_traj = 0, 0
        for user in users:
            count_user += 1
            if count_user % 50 == 0:
                print("count:", epoch, count_user)
            trajs = user_train_trajs[user]
            for traj in trajs:
                count_traj += 1
                seq   = [traj[i][8] for i in range(len(traj))]
                inp, tar = get_train_sample(seq, poi_index)
                if torch.cuda.is_available():
                    inp = inp.cuda()
                loss = train(user, inp, tar)
                # hidden = Variable(hidden.data)  
                loss_avg += loss
                # print("\nloss:", loss)
        loss_avg = loss_avg / count_traj
        print("The average loss is", loss_avg)
    print("Saving...")
    save()

except KeyboardInterrupt:
    print("Saving before quit...")
    save()

print(datetime.now())
print(datetime.now()-start_time)