import os
from datetime import datetime

import torch
from torch.autograd import Variable
from model import *

import para_config

start = datetime.now()
print(start)


print("===============predict===============\n")

# load files and parameters
model_file = para_config.model_file
pickle_file = para_config.PICKLE_FILE
rec_file = para_config.recommendation_file
rnn_model = torch.load(model_file)

def get_TopN_recs(out):
    """extract the 
    """

def predict(user, inp, rnn_model):
    for poi in inp:
        poi_index = Variable(torch.LongTensor([poi_matrix_map_dict[poi]]))
        output = rnn_model(user, poi_index)
    output = output.data.view(-1).numpy().tolist()
    sorted_output = sorted(output, reverse=True)
    return [poi_matrix_map_sw_dict[output.index(so)] for so in sorted_output[:topN]]


user_all_trajs, user_train_trajs, user_test_trajs, pois, user_index, poi_index = data_obj
n_users, n_pois = len(user_train_trajs.keys()), len(pois.keys())

wf = open(rec_file, 'w')
wf.write('user|r11, r12, ...|r21, r22, ...|...\n')
for user in user_test_trajs.keys():
    trajs = user_test_trajs[user]
    for traj in trajs:
        inp = [traj[i][8] for i in range(len(traj)-1)]
        out = predict(user, inp, rnn_model)
        recommendations_list = []
    for i in range(len(gt_seq)):
        # print("======\n", user)
        recommendations = predict(user, prime_seq, rnn_model)
        recommendations = ','.join(recommendations)
        recommendations_list.append(recommendations)
        prime_seq.append(gt_seq[i])
    line = user + '|' + '|'.join(recommendations_list)
    wf.write(line + '\n')
wf.close()

print(datetime.now())
print(datetime.now() - start)
