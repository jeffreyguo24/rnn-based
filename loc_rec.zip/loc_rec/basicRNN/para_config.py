import os
data = 'fs'
city = 'ny'

model_file = 'train_' + city + '.pt'
recommendation_file = 'recommendations' + city + '.csv'
if data == 'fs':
    PICKLE_FILE = '../datasets/foursquare_' + city + '/features.pkl'
elif data == 'gw':
    PICKLE_FILE = '../datasets/gowalla_' + city + '/features.pkl'

embedding_size = 40
rnn_type = 'RNN'
hidden_size = 32
learning_rate = 0.001
n_layers = 1
n_epochs = 5
nonlinearity = 'relu'
dropout = 0
batch_first = True
update = 'Adam'

