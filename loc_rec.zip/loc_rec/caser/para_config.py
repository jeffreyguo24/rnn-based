import os
data = 'fs'
city = 'ny'
wz = 12
poi_cut = 0

predict = True

Len = 139 #ny
# Len = 523 #sf
# Len = 190 #tk

model_file = 'train_' + city + '.pt'
recommendation_file = 'recommendations' + city + '.csv'
if data == 'fs':
    PICKLE_FILE = '../datasets/foursquare_' + city + '/features_' + str(wz) + '_' + str(poi_cut) + '_p3.pkl'
elif data == 'gw':
    PICKLE_FILE = '../datasets/gowalla_' + city + '/features_' + str(wz) + '_' + str(poi_cut) + '_p3.pkl'

embed_size = 100
rnn_type = 'LSTM'
hidden_size = 64
batch_size = 64
learning_rate = 0.01
n_layers = 3
n_epochs = 20
# nonlinearity = 'tanh'
nonlinearity = 'relu'
dropout = 0.0
batch_first = False
update = 'SGD'
criterion = 'cross' 

