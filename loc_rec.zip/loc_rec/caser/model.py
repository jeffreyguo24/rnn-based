import torch.nn as nn
from torch.autograd import Variable
import torch
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence
import torch.nn.functional as F
from para_config import Len


class RecurrentNet(nn.Module):
    def __init__(self, rnn_type, n_users, input_size, embed_size, hidden_size, output_size, batch_size, \
                 n_layers=1, batch_first=False, nonlinearity = 'relu', dropout=0.5):
        super(RecurrentNet, self).__init__()

        self.embed_size = embed_size
        self.hidden_size = hidden_size
        self.batch_size = batch_size
        self.type = rnn_type

        self.user_embed = nn.Embedding(n_users, embed_size)
        self.poi_embed  = nn.Embedding(input_size, embed_size)

        ###
        L= Len
        self.ac_conv = F.relu
        self.ac_fc = F.relu
        self.n_v = L-1
        self.conv_v = nn.Conv2d(1, self.n_v, (L, 1))

        lengths = [i + 1 for i in range(L)]
        self.conv_h = nn.ModuleList([nn.Conv2d(1, 16, (i, self.embed_size)) for i in lengths])

        # fully-connected layer
        self.fc1_dim_v = self.n_v * self.embed_size
        self.fc1_dim_h = 16 * len(lengths)
        fc1_dim_in = self.fc1_dim_v + self.fc1_dim_h
        self.fc1 = nn.Linear(fc1_dim_in, self.embed_size)
        ###

        if self.type =='LSTM':
            self.rnn = nn.LSTM(embed_size, hidden_size, n_layers, dropout=dropout)
        elif self.type == 'GRU':
            self.rnn = nn.GRU(embed_size, hidden_size, n_layers, nonlinearity=nonlinearity, dropout=dropout)
        elif self.type == 'RNN':
            self.rnn = nn.RNN(embed_size, hidden_size, n_layers, nonlinearity=nonlinearity, dropout=dropout)
        
        self.linear = nn.Linear(embed_size, output_size)
        # self.linear2 = nn.Linear(output_size*2, output_size)
        self.decoder = nn.Linear(hidden_size, output_size)
        self.linear3 = nn.Linear(embed_size, output_size)
        self.softmax = nn.LogSoftmax(dim=1)


    def forward(self, user_tensor, poi_tensor, sorted_length):
        """user_tensor: seq_len(max_len) * batch_size (the element indicate the idx)
           embed_user:  seq_len(max_len) * batch_size * embed_size
           the seq_len of all kinds of tensors should be the same: longest length of all sequences

           refer to https://pytorch.org/docs/master/nn.html#torch.nn.utils.rnn.pack_padded_sequence
           the input of pack_padded_sequence: seq_len * batch_size * embed_size if batch_first is false
        """ 

        embed_user = self.user_embed(user_tensor) 
        embed_poi  = self.poi_embed(poi_tensor)

        seq_len, batch_size, _ = embed_poi.size()

        item_embs = embed_poi.view(batch_size, seq_len, self.embed_size)
        item_embs = item_embs.unsqueeze(1)
        #print("item_embs:", item_embs.size())
        ###
        out, out_h, out_v = None, None, None
            # vertical conv layer
        if True:
            out_v = self.conv_v(item_embs) # bz x nv x 1 x ez
            #print("out_v:", out_v.size())
            out_v = out_v.squeeze(2) # bz x nv x ez
            #print("out_v:", out_v.size())
            out_v = out_v.view(-1, self.fc1_dim_v)  # prepare for fully connect, bz x (nv x ez)
            #print("out_v:", out_v.size()) 

            # horizontal conv layer
        out_hs = list()
        if True:
            for conv in self.conv_h:
                conv_out = self.ac_conv(conv(item_embs)) # bz x nh x (L to 1) x 1
                #print("conv_out:", conv_out.size())
                conv_out = conv_out.squeeze(3)
                #print("conv_out:", conv_out.size())
                pool_out = F.max_pool1d(conv_out, conv_out.size(2)).squeeze(2) # bz x nh
                #print("pool_out:", pool_out.size())
                out_hs.append(pool_out)
            out_h = torch.cat(out_hs, 1)  # prepare for fully connect bz x (Lxnh)
            #print("out_h:", out_h.size())

        # Fully-connected Layers
        c_out = torch.cat([out_v, out_h], 1)
        #print("c_out:", c_out.size()) # bz x (out_v dim1 + out_h dim1)
        # fully-connected layer
        z = self.ac_fc(self.fc1(c_out)) # bz x ez

        #print("z", z.size())
        ###

        packed_poi  = pack_padded_sequence(embed_poi, sorted_length.tolist())

        #print("packed_poi:", embed_poi.size())
        if torch.cuda.is_available():
            packed_poi = packed_poi.cuda()

        out, hidden = self.rnn(packed_poi)  # hidden: n_layers*n_directions x batch_size x hidden_size
        # #print("size of hidden:", hidden.size())
        out, _ = pad_packed_sequence(out) # seq_len * batch_size * output_size
        # #print("size of out:", out.size())

        out = self.decoder(out[-1, :, :]) # only take the output of last step
        user_pref = self.linear(embed_user)
        # pref = torch.cat((out, user_pref[0, :, :]), dim=1)
        pref = out + user_pref[0, :, :] + self.linear3(z)
        # #print("out:", out)
        # #print("user_pref:", user_pref[0, :, :])
        # pref = self.linear2(pref)
        out = self.softmax(pref)
        return out

    def init_hidden(self):
        if self.type == "LSTM":
            return (Variable(torch.zeros((self.n_layers, self.batch_size, self.hidden_size))),
                             Variable(torch.zeros((self.n_layers, self.batch_size, self.hidden_size))))
        elif self.type in ('GRU', 'RNN'):
            return Variable(torch.zeros((self.n_layers, self.batch_size, self.hidden_size)))
